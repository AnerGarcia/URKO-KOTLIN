package com.example.azterketa.core

object Constantes {

    const val BASE_URL="https://thesimpsonsquoteapi.glitch.me/"
}